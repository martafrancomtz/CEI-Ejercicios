

document.addEventListener( 'mousemove', (event) => {
    console.log(`X=${event.clientX}, Y=${event.clientY}`)
})




