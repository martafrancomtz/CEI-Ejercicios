let objeto = {
    tipo : "musical" ,
    color : "azul" ,
    tamaño : "enorme" ,
}

console.log(objeto.tipo)
console.log(objeto.color)
console.log(objeto.tamaño)
