let objeto = {
    tipo : "musical" ,
    color : "azul" ,
    tamaño : "enorme" ,
}

console.log(objeto.tipo)
console.log(objeto.color)
console.log(objeto.tamaño)

let = { tipo , color , tamaño } = objeto;

console.log(tipo)
console.log(color)
console.log(tamaño)