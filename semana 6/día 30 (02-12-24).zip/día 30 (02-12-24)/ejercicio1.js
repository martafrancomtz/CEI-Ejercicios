let myWindow;

function bt1(){
    myWindow = window.open(" ", " ", "width=100, height=100");
}

function bt2(){
    myWindow.close();
}

function bt3(){
    myWindow.moveTo(200,200);
}

function bt4(){
    myWindow.resizeTo(300,300);
}

function bt5(){
    myWindow.location.href = "https://www.youtube.com/"
}








//
//window.open()
//window.close()
//window.moveTo()
//window.resizeTo()
//window.location 






//Haz una web con 5 botones, busca documentación sobre las funciones 
//de la captura en la página de BOM. 
//Y haz un ejemplo de cada una que se active al pulsar un botón. 
