let strawhats = ["luffy", "nami", "zoro", "sanji", "usopp", "chopper", "nico", "franky", "Brook", "jinbe"];
console.log(strawhats[3]);
console.log(strawhats[6]);