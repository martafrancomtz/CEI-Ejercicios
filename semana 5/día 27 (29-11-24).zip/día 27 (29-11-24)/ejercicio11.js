let strawhats = ["luffy", "nami", "zoro", "sanji", "usopp", "chopper", "nico", "franky", "Brook", "jinbe"];
strawhats.forEach((personajes) => console.log(personajes));
