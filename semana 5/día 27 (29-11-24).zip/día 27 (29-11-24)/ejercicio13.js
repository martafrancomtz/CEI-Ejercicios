let strawhats = ["luffy", "nami", "zoro", "sanji", "usopp", "chopper", "nico", "franky", "Brook", "jinbe"];
let sonD = strawhats.find( personaje => personaje.includes("sanji") );
console.log(sonD)

