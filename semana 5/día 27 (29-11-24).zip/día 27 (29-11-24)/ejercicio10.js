let strawhats = ["luffy", "nami", "zoro", "sanji", "usopp", "chopper", "nico", "franky", "Brook", "jinbe"];
console.log(strawhats);
let linea = strawhats.join(",");
console.log(linea);
console.log(linea.split(","));
