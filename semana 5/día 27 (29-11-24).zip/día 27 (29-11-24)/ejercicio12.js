let strawhats = ["luffy", "nami", "zoro", "sanji", "usopp", "chopper", "nico", "franky", "Brook", "jinbe"];
let sonD = strawhats.map(personaje => personaje + " D");
console.log(sonD)

