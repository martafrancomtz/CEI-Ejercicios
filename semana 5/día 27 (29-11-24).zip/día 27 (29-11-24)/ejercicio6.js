let strawhats = ["luffy", "nami", "zoro", "sanji", "usopp", "chopper", "nico", "franky", "Brook", "jinbe"];
strawhats.splice(4,2);
console.log(strawhats);

