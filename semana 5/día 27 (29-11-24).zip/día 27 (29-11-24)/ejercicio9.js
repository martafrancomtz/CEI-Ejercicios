let strawhats = ["luffy", "nami", "zoro", "sanji", "usopp", "chopper", "nico", "franky", "Brook", "jinbe"];
let linea = strawhats.join(",");
console.log(linea);

