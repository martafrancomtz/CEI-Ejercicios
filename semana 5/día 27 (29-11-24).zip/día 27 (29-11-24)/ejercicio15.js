const alumno = ['monkey', 'd. luffy', 'pirata'];

const [nombre, apellido, curso] = alumno;

console.log(nombre);
console.log(apellido);
console.log(curso);