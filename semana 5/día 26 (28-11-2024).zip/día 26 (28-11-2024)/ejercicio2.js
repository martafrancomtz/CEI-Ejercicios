const mayorEdad = 18;
if(mayorEdad >= 18) {
    console.log("es mayor de edad")
}else {
    console.log("es menor de edad")
}
