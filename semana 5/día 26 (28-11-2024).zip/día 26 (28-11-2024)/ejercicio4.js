const mascota = "perro";

switch (mascota) {
    case "perro":
        console.log("tengo un perro");
        break;
    case "gato":
        console.log("tengo un gato");
        break;
    case "loro":
        console.log("tengo un loro");
        break;
    default:
        console.log("no tengo mascota");
        break;
}