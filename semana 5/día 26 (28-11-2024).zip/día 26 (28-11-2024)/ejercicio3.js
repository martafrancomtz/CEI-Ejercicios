let x = 8;
console.log(x);

if (x > 50) {
    console.log("Es mayor a 50");
} else if (x < 5) {
    console.log("Es menor a 5");
}else {
    console.log("Esta entre 5 y 50");
}