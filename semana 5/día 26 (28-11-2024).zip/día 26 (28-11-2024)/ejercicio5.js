let str = '';

for (let i = 0; i < 9; i++) {
    str = str + i;
}

console.log(str);