let n = 0;

while (n < 8) {
    n++;
}

console.log(n);