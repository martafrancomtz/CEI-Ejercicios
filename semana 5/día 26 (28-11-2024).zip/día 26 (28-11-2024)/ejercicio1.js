let a = 6;
let result = 'menor a 0'

if (a > 0) {
    result = 'mayor a 0'
}

console.log(result);