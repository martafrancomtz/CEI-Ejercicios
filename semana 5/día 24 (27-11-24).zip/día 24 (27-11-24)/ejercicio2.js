const elem = document.getElementById("demo");
elem.style.color = "red";